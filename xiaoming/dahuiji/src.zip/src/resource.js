/**
 * Create By Liangdong
 * */

var s_title = "标题.png";
var s_htp = "规则.png";
var s_start1 = "开撸.png";
var s_start2 = "开撸按下.png";

var s_again = "再来一发.png";
var s_again2 = "再来一发按下.png";

//var s_mother = "妈妈.png";
var s_door_open = "开的门.png";
var s_door_normal = "关的门.png";
var s_door_surprised = "吃惊.png";

var s_doorknob = "门把手.png";
var s_screen = "屏幕.png";
var s_av = "AV.gif";
var s_av1 = "AV1.png";
var s_av2 = "AV2.png";
var s_scene1 = "动物交配.png";
var s_scene2 = "金正恩.png";
var s_scene3 = "新闻联播.png";

var s_xmBody = "小明.png";
//var s_hand = "小明的手.png";
var s_hand1 = "小明的手1.png";
var s_hand2 = "小明的手2.png";
var s_hand3 = "小明的手3.png";
var s_hand4 = "小明的手4.png";
var s_hand5 = "小明的手5.png";
var s_hand6 = "小明的手6.png";

var s_head1 = "头1.png";
var s_head2 = "头2.png";
var s_head3 = "头3.png";
var s_head4 = "头4.png";
var s_head5 = "头5.png";
var s_head6 = "头6.png";
var s_head7 = "头7.png";
var s_head8 = "头8.png";


var s_body = "小明身体.png";
var s_xmbg = "xmbg.jpg";
var s_tm = "tm20.png";
var s_bg = "background.png";



var s_progress = "快感条.png";
var s_progressbg = "快感条框.png";

var s_win1 = "15内结果.png";
var s_win2 = "15-20秒结果.png";
var s_win3 = "20-25秒结果.png";
var s_win4 = "25-30秒结果.png";

var s_s1 = "射1.png";
var s_s2 = "射2.png";
var s_s3 = "射3.png";
var s_s4 = "射4.png";
var s_s5 = "射5.png";
var s_s6 = "射6.png";

var s_big_eq1 = "大一库1.png";
var s_big_eq2 = "大一库2.png";
var s_little_eq = "小一库.png";

var s_lose = "失败.png";

var s_bgmp3 = "res/muc/背景音乐.mp3";
var s_1 = "res/muc/1级换阶段声.wav";
var s_2 = "res/muc/2级换阶段声.wav";
var s_3 = "res/muc/3级换阶段声.wav";
var s_4 = "res/muc/4级换阶段声.wav";
var s_5 = "res/muc/5级换阶段声.wav";
var s_6 = "res/muc/6级换阶段声.wav";
var s_7 = "res/muc/7级换阶段声.wav";
var s_win = "res/muc/除了失败的结束.wav";
var s_eqsound = "res/muc/平时的叫声.wav";
var s_she = "res/muc/射.wav";
var s_news = "res/muc/新闻联播开场曲.mp3";
var s_avs = "res/muc/AV.wav";
var s_mother = "res/muc/妈妈吃惊.wav";
var s_littleeqs = "res/muc/新录音.m4a";
var s_littleeq2s = "res/muc/新录音2.m4a";

var g_resources = [


    //image
    {src:s_title},
    {src:s_htp},
    {src:s_start1},
    {src:s_start2},
    {src:s_again},
    {src:s_again2},

//    {src:s_mother},

    {src:s_door_open},
    {src:s_door_normal},
    {src:s_door_surprised},
    {src:s_doorknob},
    {src:s_screen},
    {src:s_av},
    {src:s_av1},
    {src:s_av2},
    {src:s_scene1},
    {src:s_scene2},
    {src:s_scene3},

    {src:s_xmBody},

//    {src:s_hand},
    {src:s_hand1},
    {src:s_hand2},
    {src:s_hand3},
    {src:s_hand4},
    {src:s_hand5},
    {src:s_hand6},

    {src:s_head1},
    {src:s_head2},
    {src:s_head3},
    {src:s_head4},
    {src:s_head5},
    {src:s_head6},
    {src:s_head7},
    {src:s_head8},
    {src:s_body},
    {src:s_progress},
    {src:s_xmbg},
    {src:s_tm},
    {src:s_bg},

    {src:s_win1},
    {src:s_win2},
    {src:s_win3},
    {src:s_win4},
    {src:s_lose},

    {src:s_s1},
    {src:s_s2},
    {src:s_s3},
    {src:s_s4},
    {src:s_s5},
    {src:s_s6},
    {src:s_big_eq1},
    {src:s_big_eq2},
    {src:s_little_eq},
    //mp3
    {src:s_bgmp3},
    {src:s_1},
    {src:s_2},
    {src:s_3},
    {src:s_4},
    {src:s_5},
    {src:s_6},
    {src:s_7},
    {src:s_win},
    {src:s_eqsound},
    {src:s_she},
    {src:s_news},
    {src:s_avs},
    {src:s_mother},
    {src:s_littleeqs},
    {src:s_littleeq2s}
    //plist

    //fnt

    //tmx

    //bgm

    //effect
];